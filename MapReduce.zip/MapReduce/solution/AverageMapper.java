package solution;

import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.io.FloatWritable;

public class AverageMapper extends Mapper<LongWritable, Text, Text, FloatWritable>
{
	public void map(LongWritable key, Text countryRecord, Context con)
		throws IOException, InterruptedException {

		String[] word = countryRecord.toString().split(",",-1);
 		 String country = word[1];
 		 try {
 		  Float mortRate = Float.parseFloat(word[3]);
 		  con.write(new Text(country), new FloatWritable(mortRate));
			  } catch (Exception e) {
			   e.printStackTrace();
		  }
	 }
}